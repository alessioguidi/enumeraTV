{
	"wm.AppRoot": {
	}, 
	"wm.TabLayers": {
	}, 
	"wm.Button": {
		"border": 0
	}, 
	"wm.ToggleButton": {
		"border": 0
	}, 
	"wm.PopupMenuButton": {
		"border": 0
	}, 
	"wm.ToggleButtonPanel": {
	}, 
	"wm.Text": {
	}, 
	"wm.LargeTextArea": {
	}, 
	"wm.Number": {
	}, 
	"wm.Currency": {
	}, 
	"wm.SelectMenu": {
	}, 
	"wm.Lookup": {
	}, 
	"wm.FilteringLookup": {
	}, 
	"wm.Checkbox": {
	}, 
	"wm.RadioButton": {
	}, 
	"wm.RichText": {
	}, 
	"wm.CheckboxSet": {
	}, 
	"wm.RadioSet": {
	}, 
	"wm.ListSet": {
	}, 
	"wm.Slider": {
	}, 
	"wm.DojoGrid": {
	}, 
	"wm.List": {
	}, 
	"wm.DojoMenu": {
	}
}