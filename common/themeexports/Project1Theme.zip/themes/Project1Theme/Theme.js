{
	"wm.AppRoot": {
	}, 
	"wm.Button": {
		"border": 0
	}, 
	"wm.ToggleButton": {
		"border": 0
	}, 
	"wm.PopupMenuButton": {
		"border": 0
	}
}